<?PHP

virtual("/cgi-bin/filechucker.cgi?" . $_SERVER['QUERY_STRING']);

?>
